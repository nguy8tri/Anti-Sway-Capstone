var searchData=
[
  ['discrete_2dlib_2ec_0',['discrete-lib.c',['../discrete-lib_8c.html',1,'']]],
  ['discrete_2dlib_2eh_1',['discrete-lib.h',['../discrete-lib_8h.html',1,'']]]
];
