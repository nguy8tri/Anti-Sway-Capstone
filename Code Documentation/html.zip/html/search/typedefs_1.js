var searchData=
[
  ['proportional_0',['Proportional',['../discrete-lib_8h.html#a843b842e5066711775adbb4283ab7123',1,'discrete-lib.h']]]
];
