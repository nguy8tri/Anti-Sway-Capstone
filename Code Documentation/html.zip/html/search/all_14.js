var searchData=
[
  ['wait_0',['wait',['../io_8c.html#a6b4d3d4c708b7dfb8f1a3281228c1476',1,'io.c']]]
];
