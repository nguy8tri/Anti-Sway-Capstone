var searchData=
[
  ['x_5fangle_0',['x_angle',['../struct_angles.html#ad1b9f2ec1d1b3ce38fe28c8ca6f1aa8b',1,'Angles']]],
  ['x_5fcontrol_1',['x_control',['../anti-sway_8c.html#a392cea191a15637bfe8026e378b98bc0',1,'anti-sway.c']]],
  ['x_5fpos_2',['x_pos',['../struct_positions.html#a58bd01dd4c528d52bb6babfbc72290ac',1,'Positions']]],
  ['x_5fvel_3',['x_vel',['../struct_velocities.html#a2df4ab610f9a75f9086062a4f5defb46',1,'Velocities']]]
];
