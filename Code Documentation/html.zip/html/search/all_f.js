var searchData=
[
  ['reallocatehelper_0',['ReallocateHelper',['../record_8c.html#a7566156be85c632b77aa467f8bd29250',1,'record.c']]],
  ['record_2ec_1',['record.c',['../record_8c.html',1,'']]],
  ['record_2eh_2',['record.h',['../record_8h.html',1,'']]],
  ['recorddata_3',['RecordData',['../record_8c.html#a4e8f7939cca5f98bd4c0d77dc86a1238',1,'RecordData(FileID_t file, double data[], int data_length):&#160;record.c'],['../record_8h.html#a4e8f7939cca5f98bd4c0d77dc86a1238',1,'RecordData(FileID_t file, double data[], int data_length):&#160;record.c']]],
  ['recordvalue_4',['RecordValue',['../record_8c.html#a9f4af0dd1c73fb2986a7936c67574553',1,'RecordValue(FileID_t file, char *value_name, double value):&#160;record.c'],['../record_8h.html#a9f4af0dd1c73fb2986a7936c67574553',1,'RecordValue(FileID_t file, char *value_name, double value):&#160;record.c']]],
  ['register_5ftimer_5',['REGISTER_TIMER',['../thread-lib_8h.html#a455689a1d61abe5203ec65135fd4b1d1',1,'thread-lib.h']]],
  ['reset_6',['Reset',['../io_8c.html#a372de693ad40b3f42839c8ec6ac845f4',1,'Reset():&#160;io.c'],['../io_8h.html#a372de693ad40b3f42839c8ec6ac845f4',1,'Reset():&#160;io.c']]]
];
