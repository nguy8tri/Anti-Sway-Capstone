var searchData=
[
  ['deallocatehelper_0',['DeallocateHelper',['../record_8c.html#ad65d75df875305837c1feebab27abbc1',1,'record.c']]],
  ['differentiate_1',['Differentiate',['../discrete-lib_8c.html#a1edb32f5f618b2127621dc893eca00b0',1,'Differentiate(double input, Differentiator *term, double lower_lim, double upper_lim):&#160;discrete-lib.c'],['../discrete-lib_8h.html#a1edb32f5f618b2127621dc893eca00b0',1,'Differentiate(double input, Differentiator *term, double lower_lim, double upper_lim):&#160;discrete-lib.c']]],
  ['differentiatorinit_2',['DifferentiatorInit',['../discrete-lib_8c.html#abf49b9ab36bfb597a31aa07a181060f4',1,'DifferentiatorInit(Proportional gain, double timestep, Differentiator *result):&#160;discrete-lib.c'],['../discrete-lib_8h.html#abf49b9ab36bfb597a31aa07a181060f4',1,'DifferentiatorInit(Proportional gain, double timestep, Differentiator *result):&#160;discrete-lib.c']]]
];
