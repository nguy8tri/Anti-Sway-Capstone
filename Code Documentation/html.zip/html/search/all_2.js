var searchData=
[
  ['cascade_0',['Cascade',['../discrete-lib_8c.html#a82440a88c7deb10c36dc52bd4fd9604b',1,'Cascade(double input, Biquad sys[], int size, double lower_lim, double upper_lim):&#160;discrete-lib.c'],['../discrete-lib_8h.html#a82440a88c7deb10c36dc52bd4fd9604b',1,'Cascade(double input, Biquad sys[], int size, double lower_lim, double upper_lim):&#160;discrete-lib.c']]],
  ['combined_5fconstants_1',['combined_constants',['../struct_tracking_control_scheme.html#a9e37e8bde5f7aa6882ff6cdeb50d27e3',1,'TrackingControlScheme']]]
];
