var searchData=
[
  ['y_5fangle_0',['y_angle',['../struct_angles.html#a1edfed3314837604f30be3dbc5cdff6b',1,'Angles']]],
  ['y_5fcontrol_1',['y_control',['../anti-sway_8c.html#a629c51d39bccc6bc2623b393e8673481',1,'anti-sway.c']]],
  ['y_5fpos_2',['y_pos',['../struct_positions.html#a6050d2b8c91fabde57c03ff03d3dcc16',1,'Positions']]],
  ['y_5fvel_3',['y_vel',['../struct_velocities.html#a3175a0c21c0e1a3a09666201e9ead54e',1,'Velocities']]]
];
