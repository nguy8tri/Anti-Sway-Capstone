var searchData=
[
  ['numerator_0',['numerator',['../struct_biquad.html#a61e5e08da2e66d64f1876ad0611078b1',1,'Biquad']]]
];
