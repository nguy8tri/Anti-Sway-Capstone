var searchData=
[
  ['saturate_0',['SATURATE',['../discrete-lib_8c.html#a67a7a1104ec7e0a91b2b2273e88667ab',1,'discrete-lib.c']]],
  ['start_5fthread_1',['START_THREAD',['../thread-lib_8h.html#a026d08b407bd5430893a2f27602adc27',1,'thread-lib.h']]],
  ['stop_5fthread_2',['STOP_THREAD',['../thread-lib_8h.html#a01a443ae9ae39278e1b359175835e97a',1,'thread-lib.h']]]
];
