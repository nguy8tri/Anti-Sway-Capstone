var searchData=
[
  ['datafile_5ft_0',['DataFile_t',['../struct_data_file__t.html',1,'']]],
  ['differentiator_1',['Differentiator',['../struct_differentiator.html',1,'']]]
];
