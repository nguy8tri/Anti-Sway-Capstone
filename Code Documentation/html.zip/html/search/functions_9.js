var searchData=
[
  ['opendatafile_0',['OpenDataFile',['../record_8c.html#a6ed72a430e567bb2944a36c7d4417a52',1,'OpenDataFile(char *name, char **entry_names, int num_entries):&#160;record.c'],['../record_8h.html#a6ed72a430e567bb2944a36c7d4417a52',1,'OpenDataFile(char *name, char **entry_names, int num_entries):&#160;record.c']]]
];
