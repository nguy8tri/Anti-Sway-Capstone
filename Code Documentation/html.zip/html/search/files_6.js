var searchData=
[
  ['setup_2ec_0',['setup.c',['../setup_8c.html',1,'']]],
  ['setup_2eh_1',['setup.h',['../setup_8h.html',1,'']]],
  ['system_2ec_2',['system.c',['../system_8c.html',1,'']]],
  ['system_2eh_3',['system.h',['../system_8h.html',1,'']]]
];
