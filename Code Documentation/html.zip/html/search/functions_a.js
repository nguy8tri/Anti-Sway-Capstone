var searchData=
[
  ['pid_0',['PID',['../discrete-lib_8c.html#aaa5dc3cc4d9231b3245057fee9103d13',1,'PID(double input, Proportional *p, Integrator *i, Differentiator *d, double lower_lim, double upper_lim):&#160;discrete-lib.c'],['../discrete-lib_8h.html#aaa5dc3cc4d9231b3245057fee9103d13',1,'PID(double input, Proportional *p, Integrator *i, Differentiator *d, double lower_lim, double upper_lim):&#160;discrete-lib.c']]],
  ['presseddelete_1',['PressedDelete',['../io_8c.html#a78356349ecab59eb0251d1f05b16c38b',1,'PressedDelete():&#160;io.c'],['../io_8h.html#a78356349ecab59eb0251d1f05b16c38b',1,'PressedDelete():&#160;io.c']]]
];
