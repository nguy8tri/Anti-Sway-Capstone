var searchData=
[
  ['cascade_0',['Cascade',['../discrete-lib_8c.html#a82440a88c7deb10c36dc52bd4fd9604b',1,'Cascade(double input, Biquad sys[], int size, double lower_lim, double upper_lim):&#160;discrete-lib.c'],['../discrete-lib_8h.html#a82440a88c7deb10c36dc52bd4fd9604b',1,'Cascade(double input, Biquad sys[], int size, double lower_lim, double upper_lim):&#160;discrete-lib.c']]]
];
