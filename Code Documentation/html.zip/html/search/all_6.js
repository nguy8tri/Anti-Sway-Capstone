var searchData=
[
  ['g_0',['g',['../thread-lib_8h.html#a167d2c0ec9b943d55f2124f7442b2f6d',1,'thread-lib.h']]],
  ['getangle_1',['GetAngle',['../io_8c.html#a6464ecd89623f2f77f41894d032fcaef',1,'GetAngle(Angles *result):&#160;io.c'],['../io_8h.html#a6464ecd89623f2f77f41894d032fcaef',1,'GetAngle(Angles *result):&#160;io.c']]],
  ['getreferenceanglecommand_2',['GetReferenceAngleCommand',['../io_8c.html#a82eebee08f3a434bbc7e4793163c2c15',1,'GetReferenceAngleCommand(Angles *result):&#160;io.c'],['../io_8h.html#a82eebee08f3a434bbc7e4793163c2c15',1,'GetReferenceAngleCommand(Angles *result):&#160;io.c']]],
  ['getreferencevelocitycommand_3',['GetReferenceVelocityCommand',['../io_8c.html#a99abade59aec0f9a5238fcc47e788852',1,'GetReferenceVelocityCommand(Velocities *result):&#160;io.c'],['../io_8h.html#a99abade59aec0f9a5238fcc47e788852',1,'GetReferenceVelocityCommand(Velocities *result):&#160;io.c']]],
  ['gettrolleyposition_4',['GetTrolleyPosition',['../io_8c.html#ae63c00627326f08d2a4622a84d1e747a',1,'GetTrolleyPosition(Positions *result):&#160;io.c'],['../io_8h.html#ae63c00627326f08d2a4622a84d1e747a',1,'GetTrolleyPosition(Positions *result):&#160;io.c']]],
  ['gettrolleyvelocity_5',['GetTrolleyVelocity',['../io_8c.html#a02c2b9ef38ab4815a63510c93971e904',1,'GetTrolleyVelocity(Velocities *result):&#160;io.c'],['../io_8h.html#a02c2b9ef38ab4815a63510c93971e904',1,'GetTrolleyVelocity(Velocities *result):&#160;io.c']]],
  ['getuserposition_6',['GetUserPosition',['../io_8c.html#adcb3dcf93416a844bdbfe3a11c81881a',1,'GetUserPosition(Angles *angle, Positions *pos, Positions *result):&#160;io.c'],['../io_8h.html#adcb3dcf93416a844bdbfe3a11c81881a',1,'GetUserPosition(Angles *angle, Positions *pos, Positions *result):&#160;io.c']]],
  ['getuservelocity_7',['GetUserVelocity',['../io_8c.html#ab31e062d140eefdddbfdd5de1dc6f595',1,'GetUserVelocity(Angles *angle, Velocities *vel, Velocities *result):&#160;io.c'],['../io_8h.html#ab31e062d140eefdddbfdd5de1dc6f595',1,'GetUserVelocity(Angles *angle, Velocities *vel, Velocities *result):&#160;io.c']]]
];
