var searchData=
[
  ['damping_0',['damping',['../struct_tracking_control_scheme.html#a1daa5dad0f12ce934792fd23c6b37c97',1,'TrackingControlScheme']]],
  ['data_1',['data',['../anti-sway_8c.html#a7b4664587f00f51bc74963d9c3591790',1,'anti-sway.c']]],
  ['data_5fbuff_2',['data_buff',['../anti-sway_8c.html#a053a521868d16e054ab23866422b4003',1,'anti-sway.c']]],
  ['data_5ffile_5fname_3',['data_file_name',['../anti-sway_8c.html#a619bd77e030a7a2f68d4cc7a13bdcbf5',1,'anti-sway.c']]],
  ['data_5flen_4',['DATA_LEN',['../anti-sway_8c.html#af02e45f15080b8ec9dd7b286157617ff',1,'anti-sway.c']]],
  ['data_5fnames_5',['data_names',['../anti-sway_8c.html#a3df6c268eb9de3b584cd89f9058f30f6',1,'anti-sway.c']]],
  ['datafile_5ft_6',['DataFile_t',['../struct_data_file__t.html',1,'']]],
  ['deallocatehelper_7',['DeallocateHelper',['../record_8c.html#ad65d75df875305837c1feebab27abbc1',1,'record.c']]],
  ['denominator_8',['denominator',['../struct_biquad.html#abc9f2dee3d595a51e0888eb033d15b52',1,'Biquad']]],
  ['differentiate_9',['Differentiate',['../discrete-lib_8c.html#a1edb32f5f618b2127621dc893eca00b0',1,'Differentiate(double input, Differentiator *term, double lower_lim, double upper_lim):&#160;discrete-lib.c'],['../discrete-lib_8h.html#a1edb32f5f618b2127621dc893eca00b0',1,'Differentiate(double input, Differentiator *term, double lower_lim, double upper_lim):&#160;discrete-lib.c']]],
  ['differentiator_10',['Differentiator',['../struct_differentiator.html',1,'']]],
  ['differentiatorinit_11',['DifferentiatorInit',['../discrete-lib_8c.html#abf49b9ab36bfb597a31aa07a181060f4',1,'DifferentiatorInit(Proportional gain, double timestep, Differentiator *result):&#160;discrete-lib.c'],['../discrete-lib_8h.html#abf49b9ab36bfb597a31aa07a181060f4',1,'DifferentiatorInit(Proportional gain, double timestep, Differentiator *result):&#160;discrete-lib.c']]],
  ['discrete_2dlib_2ec_12',['discrete-lib.c',['../discrete-lib_8c.html',1,'']]],
  ['discrete_2dlib_2eh_13',['discrete-lib.h',['../discrete-lib_8h.html',1,'']]],
  ['dki_14',['dKi',['../anti-sway_8c.html#a8b5b80d8a17499e769f0bbdd30530c48',1,'anti-sway.c']]],
  ['dkp_15',['dKp',['../anti-sway_8c.html#afb8d277465143ccab6da9f47e6ee87d1',1,'anti-sway.c']]]
];
