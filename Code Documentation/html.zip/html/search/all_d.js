var searchData=
[
  ['opendatafile_0',['OpenDataFile',['../record_8c.html#a6ed72a430e567bb2944a36c7d4417a52',1,'OpenDataFile(char *name, char **entry_names, int num_entries):&#160;record.c'],['../record_8h.html#a6ed72a430e567bb2944a36c7d4417a52',1,'OpenDataFile(char *name, char **entry_names, int num_entries):&#160;record.c']]],
  ['outer_5ffeedback_1',['outer_feedback',['../struct_anti_sway_control_scheme.html#a315ca8e5bb3662b0ff6fb830d9640b89',1,'AntiSwayControlScheme']]]
];
